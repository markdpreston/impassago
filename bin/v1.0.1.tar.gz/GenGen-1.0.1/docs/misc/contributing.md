## Contributing databases

If you would like to share a file or dataset that you compiled to other users, please drop me an email at kai@openbioinformatics.org and we can discuss appropriate ways to host the database.

## Contributing source codes or documentation

Please fork the [GitHub repository](https://github.com/WangGenomicsLab/penncnv), modify it, and submit a pull request to us. We will incorporate the change promptly after review.




