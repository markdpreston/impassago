Most of the programs in GenGen package are written in Perl, but some programs require a component written in C and are therefore less cross-platfrom compatible.

If using Unix/Linux system, please re-compile executable by these steps:

1. unzip the source tar.gz file (for example, using `tar xvfz gengen.tar.gz`)
2. cd into the kext/ directory
3. optionally edit the `Makefile` to change options
4. type `make`

If there is no error message, the installation is done! Now try to add the installation directory to your system PATH environment variable.

